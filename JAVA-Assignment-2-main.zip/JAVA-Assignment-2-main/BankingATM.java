import java.util.Scanner;

class Account {
    private String accNo;
    private String holderName;
    private double balance;

    // Constructor
    public Account(String accNo, String holderName) {
        this.accNo = accNo;
        this.holderName = holderName;
        this.balance = 0;
    }

    // Deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Invalid deposit amount");
        }
    }

    // Withdraw money
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Insufficient balance or invalid amount");
        }
    }

    // Get balance
    public double getBalance() {
        return balance;
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Create account
        Account account = new Account("A001", "User");

        // Input:
        // 3
        // deposit 1000
        // withdraw 500
        // getBalance

        int n = Integer.parseInt(sc.nextLine().trim());

        for (int i = 0; i < n; i++) {

            String input = sc.nextLine().trim();
            String[] data = input.split("\\s+");

            String operation = data[0];

            if (operation.equalsIgnoreCase("deposit")) {

                double amount = Double.parseDouble(data[1]);
                account.deposit(amount);

            } else if (operation.equalsIgnoreCase("withdraw")) {

                double amount = Double.parseDouble(data[1]);
                account.withdraw(amount);

            } else if (operation.equalsIgnoreCase("getBalance")) {

                System.out.println("Balance: " + account.getBalance());

            } else {

                System.out.println("Invalid operation");
            }
        }

        sc.close();
    }
}