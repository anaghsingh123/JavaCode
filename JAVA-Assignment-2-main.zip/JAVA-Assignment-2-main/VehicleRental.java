import java.util.Scanner;

class Vehicle {
    private String regNo;
    private String brand;
    private double baseRate;

    // Default constructor
    public Vehicle() {
    }

    // Parameterized constructor
    public Vehicle(String regNo, String brand, double baseRate) {
        this.regNo = regNo;
        this.brand = brand;
        this.baseRate = baseRate;
    }

    // Getters
    public String getRegNo() {
        return regNo;
    }

    public String getBrand() {
        return brand;
    }

    public double getBaseRate() {
        return baseRate;
    }

    // Setters
    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setBaseRate(double baseRate) {
        this.baseRate = baseRate;
    }

    // Method to calculate rental rate
    public double calculateRate() {
        return baseRate;
    }

    // toString()
    @Override
    public String toString() {
        return "Registration No: " + regNo +
               ", Brand: " + brand +
               ", Base Rate: " + baseRate +
               ", Rental Rate: " + calculateRate();
    }
}

// Car class
class Car extends Vehicle {

    public Car(String regNo, String brand, double baseRate) {
        super(regNo, brand, baseRate);
    }

    // Car rate = baseRate * 1.5
    @Override
    public double calculateRate() {
        return getBaseRate() * 1.5;
    }
}

// Bike class
class Bike extends Vehicle {

    public Bike(String regNo, String brand, double baseRate) {
        super(regNo, brand, baseRate);
    }

    // Bike rate = baseRate * 1.2
    @Override
    public double calculateRate() {
        return getBaseRate() * 1.2;
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input:
        // Car,KA01AA1234,Toyota,1000
        String input = sc.nextLine();

        String[] data = input.split(",");

        String type = data[0].trim();
        String regNo = data[1].trim();
        String brand = data[2].trim();
        double baseRate = Double.parseDouble(data[3].trim());

        Vehicle vehicle;

        // Polymorphism
        if (type.equalsIgnoreCase("Car")) {
            vehicle = new Car(regNo, brand, baseRate);
        } else if (type.equalsIgnoreCase("Bike")) {
            vehicle = new Bike(regNo, brand, baseRate);
        } else {
            System.out.println("Invalid vehicle type");
            sc.close();
            return;
        }

        // Display details
        System.out.println(vehicle);

        sc.close();
    }
}