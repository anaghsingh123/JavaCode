import java.util.Scanner;

class Room {
    private String roomNumber;
    private String block;
    private String type;

    // Default constructor
    public Room() {
    }

    // Parameterized constructor
    public Room(String roomNumber, String block, String type) {
        this.roomNumber = roomNumber;
        this.block = block;
        this.type = type;
    }

    // Getters
    public String getRoomNumber() {
        return roomNumber;
    }

    public String getBlock() {
        return block;
    }

    public String getType() {
        return type;
    }

    // Setters
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public void setType(String type) {
        this.type = type;
    }

    // toString()
    @Override
    public String toString() {
        return "Room Number: " + roomNumber +
               ", Block: " + block +
               ", Type: " + type;
    }
}

class Student {
    private String name;
    private String roll;
    private String course;
    private Room room;

    // Default constructor
    public Student() {
    }

    // Parameterized constructor
    public Student(String name, String roll, String course, Room room) {
        this.name = name;
        this.roll = roll;
        this.course = course;
        this.room = room;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getRoll() {
        return roll;
    }

    public String getCourse() {
        return course;
    }

    public Room getRoom() {
        return room;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    // toString()
    @Override
    public String toString() {
        return "Student Name: " + name +
               ", Roll: " + roll +
               ", Course: " + course +
               ", " + room;
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input:
        // Ravi,101,CSE,A101,Block-B,Single
        String input = sc.nextLine();

        String[] data = input.split(",");

        String name = data[0].trim();
        String roll = data[1].trim();
        String course = data[2].trim();
        String roomNumber = data[3].trim();
        String block = data[4].trim();
        String type = data[5].trim();

        // Create Room object
        Room room = new Room(roomNumber, block, type);

        // Create Student object
        Student student = new Student(name, roll, course, room);

        // Display details
        System.out.println(student);

        sc.close();
    }
}