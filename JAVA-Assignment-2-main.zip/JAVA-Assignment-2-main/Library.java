import java.util.Scanner;

class Author {
    private String name;
    private String email;
    private char gender;

    // Default constructor
    public Author() {
    }

    // Parameterized constructor
    public Author(String name, String email, char gender) {
        this.name = name;
        this.email = email;
        this.gender = gender;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public char getGender() {
        return gender;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    // toString()
    @Override
    public String toString() {
        return "Author Name: " + name +
               ", Email: " + email +
               ", Gender: " + gender;
    }
}

class Book {
    private String title;
    private double price;
    private Author author;

    // Default constructor
    public Book() {
    }

    // Parameterized constructor
    public Book(String title, double price, Author author) {
        this.title = title;
        this.price = price;
        this.author = author;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public double getPrice() {
        return price;
    }

    public Author getAuthor() {
        return author;
    }

    // Setters
    public void setTitle(String title) {
        this.title = title;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    // toString()
    @Override
    public String toString() {
        return "Book Title: " + title +
               ", Price: " + price +
               ", " + author;
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input:
        // Effective Java,550,Joshua Bloch,jbloch@abc.com,M
        String input = sc.nextLine();

        String[] data = input.split(",");

        String title = data[0].trim();
        double price = Double.parseDouble(data[1].trim());
        String authorName = data[2].trim();
        String email = data[3].trim();
        char gender = data[4].trim().charAt(0);

        // Create Author object
        Author author = new Author(authorName, email, gender);

        // Create Book object
        Book book = new Book(title, price, author);

        // Display book details
        System.out.println(book);

        sc.close();
    }
}