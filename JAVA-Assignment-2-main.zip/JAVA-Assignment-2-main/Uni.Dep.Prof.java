import java.util.Scanner;

class Professor {
    private String name;
    private String employeeId;
    private String specialization;

    // Default constructor
    Professor() {
    }

    // Parameterized constructor
    Professor(String name, String employeeId, String specialization) {
        this.name = name;
        this.employeeId = employeeId;
        this.specialization = specialization;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public String getSpecialization() {
        return specialization;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    @Override
    public String toString() {
        return "Name: " + name +
               ", ID: " + employeeId +
               ", Specialization: " + specialization;
    }
}


class Department {
    private String deptName;
    private String hodName;
    private Professor[] professors;
    private int count;

    // Default constructor
    Department() {
        professors = new Professor[100];
        count = 0;
    }

    // Parameterized constructor
    Department(String deptName, String hodName) {
        this.deptName = deptName;
        this.hodName = hodName;
        professors = new Professor[100];
        count = 0;
    }

    // Getters
    public String getDeptName() {
        return deptName;
    }

    public String getHodName() {
        return hodName;
    }

    public Professor[] getProfessors() {
        return professors;
    }

    // Setters
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public void setHodName(String hodName) {
        this.hodName = hodName;
    }

    public void setProfessors(Professor[] professors) {
        this.professors = professors;
    }

    // Add professor
    public void addProfessor(Professor p) {
        if (count < professors.length) {
            professors[count] = p;
            count++;
        }
    }

    @Override
    public String toString() {
        String result = "Department: " + deptName +
                        "\nHOD: " + hodName +
                        "\nProfessors:\n";

        for (int i = 0; i < count; i++) {
            result += professors[i] + "\n";
        }

        return result;
    }
}


public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Department details
        System.out.println("Enter Department details (deptName,hodName)");
        String deptInput = sc.nextLine();

        String[] deptData = deptInput.split(",");

        String deptName = deptData[0].trim();
        String hodName = deptData[1].trim();

        Department dept = new Department(deptName, hodName);

        // Number of professors
        System.out.println("Enter number of professors");
        int n = Integer.parseInt(sc.nextLine());

        // Professor details
        System.out.println("Enter professor details (name,employeeId,specialization)");

        for (int i = 0; i < n; i++) {

            String professorInput = sc.nextLine();

            String[] professorData = professorInput.split(",");

            String name = professorData[0].trim();
            String employeeId = professorData[1].trim();
            String specialization = professorData[2].trim();

            Professor p = new Professor(
                    name,
                    employeeId,
                    specialization
            );

            dept.addProfessor(p);
        }

        // Display output
        System.out.println();
        System.out.println(dept);

        sc.close();
    }
}