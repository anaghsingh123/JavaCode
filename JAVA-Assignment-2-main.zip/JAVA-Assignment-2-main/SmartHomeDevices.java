import java.util.Scanner;

interface Device {
    void turnOn();
    void turnOff();
}

class Fan implements Device {

    @Override
    public void turnOn() {
        System.out.println("Fan is turned ON");
    }

    @Override
    public void turnOff() {
        System.out.println("Fan is turned OFF");
    }
}

class Light implements Device {

    @Override
    public void turnOn() {
        System.out.println("Light is turned ON");
    }

    @Override
    public void turnOff() {
        System.out.println("Light is turned OFF");
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input: Fan Light
        String input = sc.nextLine();
        String[] devices = input.split("\\s+");

        for (String deviceName : devices) {

            Device device;

            if (deviceName.equalsIgnoreCase("Fan")) {
                device = new Fan();
            } else if (deviceName.equalsIgnoreCase("Light")) {
                device = new Light();
            } else {
                System.out.println("Invalid device: " + deviceName);
                continue;
            }

            // Polymorphism
            device.turnOn();
            device.turnOff();
        }

        sc.close();
    }
}