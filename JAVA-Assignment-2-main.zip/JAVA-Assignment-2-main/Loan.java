import java.util.Scanner;

abstract class Loan {
    private double principal;
    private double rate;
    private double time;

    // Constructor
    public Loan(double principal, double rate, double time) {
        this.principal = principal;
        this.rate = rate;
        this.time = time;
    }

    // Getters
    public double getPrincipal() {
        return principal;
    }

    public double getRate() {
        return rate;
    }

    public double getTime() {
        return time;
    }

    // Abstract method
    public abstract double calculateInterest();

    // toString()
    @Override
    public String toString() {
        return "Principal: " + principal +
               ", Rate: " + rate + "%" +
               ", Time: " + time +
               ", Interest: " + calculateInterest();
    }
}

// Home Loan
class HomeLoan extends Loan {

    public HomeLoan(double principal, double time) {
        super(principal, 8, time);
    }

    // SI = (P * R * T) / 100
    @Override
    public double calculateInterest() {
        return (getPrincipal() * getRate() * getTime()) / 100;
    }
}

// Car Loan
class CarLoan extends Loan {

    public CarLoan(double principal, double time) {
        super(principal, 10, time);
    }

    // SI = (P * R * T) / 100
    @Override
    public double calculateInterest() {
        return (getPrincipal() * getRate() * getTime()) / 100;
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input:
        // Home,500000,8
        String input = sc.nextLine();

        String[] data = input.split(",");

        String type = data[0].trim();
        double principal = Double.parseDouble(data[1].trim());
        double time = Double.parseDouble(data[2].trim());

        Loan loan;

        // Polymorphism
        if (type.equalsIgnoreCase("Home")) {
            loan = new HomeLoan(principal, time);
        } else if (type.equalsIgnoreCase("Car")) {
            loan = new CarLoan(principal, time);
        } else {
            System.out.println("Invalid loan type");
            sc.close();
            return;
        }

        // Display loan details
        System.out.println(loan);

        sc.close();
    }
}