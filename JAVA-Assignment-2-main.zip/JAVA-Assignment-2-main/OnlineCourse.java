import java.util.Scanner;

class Course {
    private String courseName;
    private String duration;

    // Default constructor
    public Course() {
    }

    // Parameterized constructor
    public Course(String courseName, String duration) {
        this.courseName = courseName;
        this.duration = duration;
    }

    // Getters
    public String getCourseName() {
        return courseName;
    }

    public String getDuration() {
        return duration;
    }

    // Setters
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "Course: " + courseName + ", Duration: " + duration;
    }
}

class Student {
    private String name;
    private Course enrolledCourse;

    // Default constructor
    public Student() {
    }

    // Parameterized constructor
    public Student(String name, Course enrolledCourse) {
        this.name = name;
        this.enrolledCourse = enrolledCourse;
    }

    // Getters
    public String getName() {
        return name;
    }

    public Course getEnrolledCourse() {
        return enrolledCourse;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setEnrolledCourse(Course enrolledCourse) {
        this.enrolledCourse = enrolledCourse;
    }

    @Override
    public String toString() {
        return "Student: " + name + ", " + enrolledCourse;
    }
}

class PremiumStudent extends Student {
    private double discount;

    // Constructor
    public PremiumStudent(String name, Course enrolledCourse, double discount) {
        super(name, enrolledCourse);
        this.discount = discount;
    }

    // Getter
    public double getDiscount() {
        return discount;
    }

    // Setter
    public void setDiscount(double discount) {
        this.discount = discount;
    }

    @Override
    public String toString() {
        return "Premium Student: " + getName() +
               ", " + getEnrolledCourse() +
               ", Discount: " + discount + "%";
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input:
        // Java,3 months
        String courseInput = sc.nextLine();
        String[] courseData = courseInput.split(",");

        String courseName = courseData[0].trim();
        String duration = courseData[1].trim();

        Course course = new Course(courseName, duration);

        // Input:
        // Arjun,Java
        String studentInput = sc.nextLine();
        String[] studentData = studentInput.split(",");

        String studentName = studentData[0].trim();
        String studentCourse = studentData[1].trim();

        Student student = new Student(studentName, course);

        // Input:
        // Meena,Java,20
        String premiumInput = sc.nextLine();
        String[] premiumData = premiumInput.split(",");

        String premiumName = premiumData[0].trim();
        String premiumCourse = premiumData[1].trim();
        double discount = Double.parseDouble(premiumData[2].trim());

        PremiumStudent premiumStudent =
                new PremiumStudent(premiumName, course, discount);

        // Display details
        System.out.println(student);
        System.out.println(premiumStudent);

        sc.close();
    }
}