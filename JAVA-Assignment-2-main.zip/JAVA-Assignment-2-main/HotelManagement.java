import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Guest {
    private String name;
    private int age;
    private String idProof;

    // Default constructor
    public Guest() {
    }

    // Parameterized constructor
    public Guest(String name, int age, String idProof) {
        this.name = name;
        this.age = age;
        this.idProof = idProof;
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getIdProof() {
        return idProof;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setIdProof(String idProof) {
        this.idProof = idProof;
    }

    // toString()
    @Override
    public String toString() {
        return "Guest Name: " + name +
               ", Age: " + age +
               ", ID Proof: " + idProof;
    }
}

class Reservation {
    private String reservationId;
    private String roomType;
    private List<Guest> guests;

    // Default constructor
    public Reservation() {
        guests = new ArrayList<>();
    }

    // Parameterized constructor
    public Reservation(String reservationId, String roomType) {
        this.reservationId = reservationId;
        this.roomType = roomType;
        guests = new ArrayList<>();
    }

    // Getters
    public String getReservationId() {
        return reservationId;
    }

    public String getRoomType() {
        return roomType;
    }

    public List<Guest> getGuests() {
        return guests;
    }

    // Setters
    public void setReservationId(String reservationId) {
        this.reservationId = reservationId;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public void setGuests(List<Guest> guests) {
        this.guests = guests;
    }

    // Add guest
    public void addGuest(Guest guest) {
        guests.add(guest);
    }

    // toString()
    @Override
    public String toString() {
        String result = "Reservation ID: " + reservationId +
                        ", Room Type: " + roomType + "\n";

        for (Guest guest : guests) {
            result += guest + "\n";
        }

        return result;
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input:
        // R101,Deluxe,2
        String reservationInput = sc.nextLine();
        String[] reservationData = reservationInput.split(",");

        String reservationId = reservationData[0].trim();
        String roomType = reservationData[1].trim();
        int numberOfGuests = Integer.parseInt(reservationData[2].trim());

        // Create Reservation
        Reservation reservation =
                new Reservation(reservationId, roomType);

        // Read guest details
        for (int i = 0; i < numberOfGuests; i++) {

            // Input:
            // Amit,25,ID123
            String guestInput = sc.nextLine();
            String[] guestData = guestInput.split(",");

            String name = guestData[0].trim();
            int age = Integer.parseInt(guestData[1].trim());
            String idProof = guestData[2].trim();

            Guest guest = new Guest(name, age, idProof);

            reservation.addGuest(guest);
        }

        // Display reservation details
        System.out.println(reservation);

        sc.close();
    }
}