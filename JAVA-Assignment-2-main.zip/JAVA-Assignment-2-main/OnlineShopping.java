import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Product {
    private String productName;
    private double price;
    private int quantity;

    // Default constructor
    public Product() {
    }

    // Parameterized constructor
    public Product(String productName, double price, int quantity) {
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
    }

    // Getters
    public String getProductName() {
        return productName;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    // Setters
    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Calculate product total
    public double getTotal() {
        return price * quantity;
    }

    // Override toString()
    @Override
    public String toString() {
        return productName + " x " + quantity + " = " + getTotal();
    }
}

class Order {
    private String orderId;
    private List<Product> products;

    // Default constructor
    public Order() {
        products = new ArrayList<>();
    }

    // Parameterized constructor
    public Order(String orderId) {
        this.orderId = orderId;
        products = new ArrayList<>();
    }

    // Getters
    public String getOrderId() {
        return orderId;
    }

    public List<Product> getProducts() {
        return products;
    }

    // Setters
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    // Add product
    public void addProduct(Product product) {
        products.add(product);
    }

    // Calculate order total
    public double calculateTotal() {
        double total = 0;

        for (Product product : products) {
            total += product.getTotal();
        }

        return total;
    }

    // Override toString()
    @Override
    public String toString() {
        String result = "Order ID: " + orderId + "\n";

        for (Product product : products) {
            result += product + "\n";
        }

        result += "Total: " + calculateTotal();

        return result;
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Read Order ID
        String orderId = sc.nextLine().trim();

        // Read number of products
        int n = Integer.parseInt(sc.nextLine().trim());

        // Create Order
        Order order = new Order(orderId);

        // Read product details
        for (int i = 0; i < n; i++) {
            String input = sc.nextLine();

            String[] data = input.split(",");

            String productName = data[0].trim();
            double price = Double.parseDouble(data[1].trim());
            int quantity = Integer.parseInt(data[2].trim());

            Product product = new Product(productName, price, quantity);

            order.addProduct(product);
        }

        // Display order summary
        System.out.println(order);

        sc.close();
    }
}