import java.util.Scanner;

class Person {
    private String name;
    private int age;

    // Default constructor
    public Person() {
    }

    // Parameterized constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // toString()
    @Override
    public String toString() {
        return "Name: " + name + ", Age: " + age;
    }
}

class Doctor extends Person {
    private String specialization;

    // Default constructor
    public Doctor() {
    }

    // Parameterized constructor
    public Doctor(String name, int age, String specialization) {
        super(name, age);
        this.specialization = specialization;
    }

    // Getter
    public String getSpecialization() {
        return specialization;
    }

    // Setter
    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    // toString()
    @Override
    public String toString() {
        return super.toString() +
               ", Specialization: " + specialization;
    }
}

class Surgeon extends Doctor {
    private String surgeryType;

    // Default constructor
    public Surgeon() {
    }

    // Parameterized constructor
    public Surgeon(String name, int age, String specialization, String surgeryType) {
        super(name, age, specialization);
        this.surgeryType = surgeryType;
    }

    // Getter
    public String getSurgeryType() {
        return surgeryType;
    }

    // Setter
    public void setSurgeryType(String surgeryType) {
        this.surgeryType = surgeryType;
    }

    // toString()
    @Override
    public String toString() {
        return super.toString() +
               ", Surgery Type: " + surgeryType;
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input:
        // John,40,Cardiology,Heart Surgery
        String input = sc.nextLine();

        String[] data = input.split(",");

        String name = data[0].trim();
        int age = Integer.parseInt(data[1].trim());
        String specialization = data[2].trim();
        String surgeryType = data[3].trim();

        // Create Surgeon object
        Surgeon surgeon = new Surgeon(
                name,
                age,
                specialization,
                surgeryType
        );

        // Display details
        System.out.println(surgeon);

        sc.close();
    }
}