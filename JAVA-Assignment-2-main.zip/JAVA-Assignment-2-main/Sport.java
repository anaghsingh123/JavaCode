import java.util.Scanner;

class Team {
    private String name;
    private int matchesPlayed;
    private int wins;
    private int draws;

    // Default constructor
    public Team() {
    }

    // Parameterized constructor
    public Team(String name, int matchesPlayed, int wins, int draws) {
        this.name = name;
        this.matchesPlayed = matchesPlayed;
        this.wins = wins;
        this.draws = draws;
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getMatchesPlayed() {
        return matchesPlayed;
    }

    public int getWins() {
        return wins;
    }

    public int getDraws() {
        return draws;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setMatchesPlayed(int matchesPlayed) {
        this.matchesPlayed = matchesPlayed;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public void setDraws(int draws) {
        this.draws = draws;
    }

    // Base method
    public int calculatePoints() {
        return 0;
    }

    // toString()
    @Override
    public String toString() {
        return "Team: " + name +
               ", Matches Played: " + matchesPlayed +
               ", Wins: " + wins +
               ", Draws: " + draws +
               ", Points: " + calculatePoints();
    }
}

// Cricket Team
class CricketTeam extends Team {

    public CricketTeam(String name, int matchesPlayed, int wins, int draws) {
        super(name, matchesPlayed, wins, draws);
    }

    // Cricket: win = 2 points, draw = 1 point
    @Override
    public int calculatePoints() {
        return (getWins() * 2) + getDraws();
    }
}

// Football Team
class FootballTeam extends Team {

    public FootballTeam(String name, int matchesPlayed, int wins, int draws) {
        super(name, matchesPlayed, wins, draws);
    }

    // Football: win = 3 points, draw = 1 point
    @Override
    public int calculatePoints() {
        return (getWins() * 3) + getDraws();
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input:
        // Cricket,India,10,6,2
        String input = sc.nextLine();

        String[] data = input.split(",");

        String type = data[0].trim();
        String name = data[1].trim();
        int matchesPlayed = Integer.parseInt(data[2].trim());
        int wins = Integer.parseInt(data[3].trim());
        int draws = Integer.parseInt(data[4].trim());

        Team team;

        // Polymorphism
        if (type.equalsIgnoreCase("Cricket")) {
            team = new CricketTeam(name, matchesPlayed, wins, draws);
        } else if (type.equalsIgnoreCase("Football")) {
            team = new FootballTeam(name, matchesPlayed, wins, draws);
        } else {
            System.out.println("Invalid team type");
            sc.close();
            return;
        }

        // Display team details
        System.out.println(team);

        sc.close();
    }
}