import java.util.Scanner;

class Employee {
    private String name;
    private String id;
    private double basicSalary;

    // Default constructor
    public Employee() {
    }

    // Parameterized constructor
    public Employee(String name, String id, double basicSalary) {
        this.name = name;
        this.id = id;
        this.basicSalary = basicSalary;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    // Calculate salary
    public double calculateSalary() {
        return basicSalary;
    }

    // toString()
    @Override
    public String toString() {
        return "Name: " + name +
               ", ID: " + id +
               ", Salary: " + calculateSalary();
    }
}

class Manager extends Employee {
    private double bonus;

    // Constructor chaining using super()
    public Manager(String name, String id, double basicSalary, double bonus) {
        super(name, id, basicSalary);
        this.bonus = bonus;
    }

    // Override calculateSalary()
    @Override
    public double calculateSalary() {
        return getBasicSalary() + bonus;
    }

    // Override toString()
    @Override
    public String toString() {
        return "Name: " + getName() +
               ", ID: " + getId() +
               ", Basic Salary: " + getBasicSalary() +
               ", Bonus: " + bonus +
               ", Salary: " + calculateSalary();
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input
        System.out.println("Enter employee details");

        String input = sc.nextLine();
        String[] data = input.split(",");

        String type = data[0].trim();

        Employee employee;

        if (type.equalsIgnoreCase("Employee")) {

            String name = data[1].trim();
            String id = data[2].trim();
            double basicSalary = Double.parseDouble(data[3].trim());

            employee = new Employee(name, id, basicSalary);

        } else if (type.equalsIgnoreCase("Manager")) {

            String name = data[1].trim();
            String id = data[2].trim();
            double basicSalary = Double.parseDouble(data[3].trim());
            double bonus = Double.parseDouble(data[4].trim());

            employee = new Manager(name, id, basicSalary, bonus);

        } else {
            System.out.println("Invalid employee type");
            sc.close();
            return;
        }

        // Display details
        System.out.println(employee);

        sc.close();
    }
}